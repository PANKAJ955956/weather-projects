
# Weather Pro – React + Tailwind CSS Weather App Frontend

This is a fully functional and visually attractive weather application frontend built using ReactJS and Tailwind CSS.

## 🌦 Features

- Search by city name
- Display temperature, weather condition, humidity, wind speed
- Tailwind CSS styling for responsive UI
- React components for modular design
- Optional: Integrate with OpenWeatherMap API

## 🚀 How to Run

1. Clone the repository or download ZIP
2. Run `npm install`
3. Replace `YOUR_API_KEY` in `Home.js` with your OpenWeatherMap API key
4. Run `npm start`

## 📂 Structure

- `components/`: Contains all reusable React components
- `public/`: Static HTML file
- `src/`: Application source code

## 📦 Submission Portal

1. Upload this project to GitHub
2. Go to: https://training.allsoftsolutions.in/
3. Login → Dashboard → Projects → Submit Project
4. Paste GitHub URL and fill other details
5. Submit for review
