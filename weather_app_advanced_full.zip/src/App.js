
import React from 'react';
import Home from './components/Home';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-gradient-to-br from-blue-100 to-blue-300 min-h-screen">
      <Navbar />
      <Home />
      <Footer />
    </div>
  );
}

export default App;
