
import React from 'react';

function WeatherCard({ data }) {
  return (
    <div className="p-6 bg-white rounded-lg shadow-lg max-w-md text-center">
      <h2 className="text-xl font-semibold">{data.name}, {data.sys.country}</h2>
      <p className="text-2xl font-bold">{data.main.temp}°C</p>
      <p>{data.weather[0].main}</p>
      <div className="flex justify-around mt-4">
        <div>
          <p className="text-sm text-gray-600">Humidity</p>
          <p>{data.main.humidity}%</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Wind Speed</p>
          <p>{data.wind.speed} m/s</p>
        </div>
      </div>
    </div>
  );
}

export default WeatherCard;
