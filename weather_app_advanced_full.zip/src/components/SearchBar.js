
import React from 'react';
import { FaSearch } from 'react-icons/fa';

function SearchBar({ query, setQuery, onSearch }) {
  return (
    <div className="flex items-center mb-6">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Enter city name..."
        className="p-2 w-64 rounded-l-md shadow border border-gray-300"
      />
      <button
        onClick={onSearch}
        className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-r-md flex items-center"
      >
        <FaSearch className="mr-1" /> Search
      </button>
    </div>
  );
}

export default SearchBar;
