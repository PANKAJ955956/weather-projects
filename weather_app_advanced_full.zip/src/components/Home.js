
import React, { useEffect, useState } from 'react';
import WeatherCard from './WeatherCard';
import SearchBar from './SearchBar';
import axios from 'axios';

function Home() {
  const [weatherData, setWeatherData] = useState(null);
  const [query, setQuery] = useState('');

  const fetchWeather = async (city) => {
    const API_KEY = 'YOUR_API_KEY';
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;
    const res = await axios.get(url);
    setWeatherData(res.data);
  };

  const handleSearch = () => {
    if (query) fetchWeather(query);
  };

  return (
    <div className="flex flex-col items-center py-10">
      <SearchBar query={query} setQuery={setQuery} onSearch={handleSearch} />
      {weatherData && <WeatherCard data={weatherData} />}
    </div>
  );
}

export default Home;
