
import React from 'react';

function Navbar() {
  return (
    <nav className="bg-white shadow-lg p-4 flex justify-between">
      <h1 className="text-2xl font-bold text-blue-600">Weather Pro</h1>
      <div className="text-sm text-gray-600">Your Reliable Weather Partner</div>
    </nav>
  );
}

export default Navbar;
